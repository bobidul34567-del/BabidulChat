package com.babulid.chat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF075E54)
private val LightGreen = Color(0xFFDCF8C6)
private val Page = Color(0xFFF5F5F5)

data class Chat(val name: String, val message: String, val time: String, val initials: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BabidulChatApp() }
    }
}

@Composable
fun BabidulChatApp() {
    var tab by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<String?>(null) }
    val chats = remember {
        mutableStateListOf(
            Chat("Rahim", "ভালে আছা নে?", "10:30", "R"),
            Chat("Karim", "ঠিক আছে।", "গতকাল", "K"),
            Chat("Family Group", "মা: ঘৰলৈ কেতিয়া আহিবা?", "গতকাল", "F"),
            Chat("School Friends", "কাইলৈ দেখা হ'ব", "মঙল", "S")
        )
    }
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Color(0xFF128C7E))) {
        if (selected != null) {
            ChatScreen(name = selected!!, onBack = { selected = null })
        } else {
            Column(Modifier.fillMaxSize().background(Page)) {
                Column(Modifier.background(Green).fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Babidul Chat", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.Search, null, tint = Color.White)
                        Spacer(Modifier.width(18.dp))
                        Icon(Icons.Default.MoreVert, null, tint = Color.White)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        listOf("চেট", "স্থিতি", "কল").forEachIndexed { index, label ->
                            Column(
                                Modifier.weight(1f).clickable { tab = index }.padding(vertical = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(label, color = Color.White, fontWeight = if (tab == index) FontWeight.Bold else FontWeight.Normal)
                                if (tab == index) Spacer(Modifier.padding(top = 8.dp).width(42.dp).height(3.dp).background(Color.White))
                            }
                        }
                    }
                }
                when (tab) {
                    0 -> LazyColumn {
                        items(chats) { chat ->
                            Row(
                                Modifier.fillMaxWidth().clickable { selected = chat.name }.padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(52.dp).background(Color(0xFFB2DFDB), CircleShape), contentAlignment = Alignment.Center) {
                                    Text(chat.initials, color = Green, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.width(13.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(chat.name, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                                    Text(chat.message, color = Color.DarkGray, fontSize = 14.sp)
                                }
                                Text(chat.time, color = Color.Gray, fontSize = 12.sp)
                            }
                            HorizontalDivider(color = Color(0xFFE7E7E7), thickness = 0.6.dp)
                        }
                    }
                    1 -> EmptyTab("স্থিতি", "আপোনাৰ স্থিতি ইয়াত দেখা যাব")
                    else -> EmptyTab("কল", "আপোনাৰ কলৰ তালিকা ইয়াত দেখা যাব")
                }
                Spacer(Modifier.weight(1f))
                Text("প্ৰাথমিক নমুনা এপ • বাৰ্তাবোৰ এই ফোনতেই থাকে", color = Color.Gray, fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth().background(Color.White).padding(8.dp))
            }
        }
    }
}

@Composable
fun EmptyTab(title: String, subtitle: String) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(if (title == "কল") Icons.Default.Call else Icons.Default.Circle, null, tint = Green, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Color.Gray)
    }
}

@Composable
fun ChatScreen(name: String, onBack: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf("নমস্কাৰ! Babidul Chat-লৈ স্বাগতম।") }
    Column(Modifier.fillMaxSize().background(Color(0xFFECE5DD))) {
        Row(Modifier.fillMaxWidth().background(Green).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ArrowBack, null, tint = Color.White, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(14.dp))
            Box(Modifier.size(38.dp).background(Color(0xFFB2DFDB), CircleShape), contentAlignment = Alignment.Center) {
                Text(name.take(1), color = Green, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(10.dp))
            Text(name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages) { msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Text(msg, modifier = Modifier.widthIn(max = 280.dp).background(LightGreen, RoundedCornerShape(12.dp)).padding(12.dp), color = Color.Black)
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(Color(0xFFF7F7F7)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("বাৰ্তা লিখক...") }, shape = RoundedCornerShape(24.dp), singleLine = true
            )
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = { if (input.isNotBlank()) { messages.add(input.trim()); input = "" } },
                modifier = Modifier.background(Green, CircleShape)) {
                Icon(Icons.Default.Send, "পঠিয়াওক", tint = Color.White)
            }
        }
    }
}
